class CORSMiddleware:
    pass
